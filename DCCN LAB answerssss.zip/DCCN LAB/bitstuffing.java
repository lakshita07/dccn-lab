import java.util.Scanner;
 class BitStuffing {

    // Method to perform bit stuffing
    public static String bitStuffing(String data) {
        StringBuilder stuffedData = new StringBuilder();
        int consecutiveOnes = 0;

        for (int i = 0; i < data.length(); i++) {
            char bit = data.charAt(i);
            stuffedData.append(bit);

            if (bit == '1') {
                consecutiveOnes++;
                if (consecutiveOnes == 5) {
                    // Insert a '0' after five consecutive '1's
                    stuffedData.append('0');
                    consecutiveOnes = 0;
                }
            } else {
                consecutiveOnes = 0;
            }
        }

        return stuffedData.toString();
    }

    // Method to perform bit unstuffing
    public static String bitUnstuffing(String stuffedData) {
        StringBuilder unstuffedData = new StringBuilder();
        int consecutiveOnes = 0;

        for (int i = 0; i < stuffedData.length(); i++) {
            char bit = stuffedData.charAt(i);

            if (bit == '1') {
                consecutiveOnes++;
                unstuffedData.append(bit);

                if (consecutiveOnes == 5) {
                    // Skip the next '0' after five consecutive '1's
                    i++; // Skip the stuffed '0'
                    consecutiveOnes = 0;
                }
            } else {
                consecutiveOnes = 0;
                unstuffedData.append(bit);
            }
        }

        return unstuffedData.toString();
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input data frame
        System.out.print("Enter the binary data frame: ");
        String data = scanner.nextLine();

        // Perform bit stuffing
        String stuffedData = bitStuffing(data);
        System.out.println("Stuffed Data: " + stuffedData);

        // Perform bit unstuffing
        String unstuffedData = bitUnstuffing(stuffedData);
        System.out.println("Unstuffed Data: " + unstuffedData);

        scanner.close();
    }
}