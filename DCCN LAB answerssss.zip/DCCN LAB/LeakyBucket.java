/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.*;

public class LeakyBucket
{
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int bucket_size = 100;
		int storage = 0;

		System.out.println("Maximum Bucket Size: "+bucket_size);
		while(true) {
			System.out.print("\nEnter the input data (to stop enter -1) : ");
			int input = in.nextInt();
			if(input == -1) {
				break;
			}

			if(storage + input <= bucket_size) {
				storage += input;
				System.out.println("Packet added.");
			}
			else {
				System.out.println("Packet loss.");
			}

			storage--;
			System.out.println("After fixed output flow of 1 data, bucket size: " + storage);
		}
	}
}