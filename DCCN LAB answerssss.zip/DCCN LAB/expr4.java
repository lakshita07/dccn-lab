import java.util.Scanner;

class expr4 {

    // Method to calculate the checksum
    public static int calculateChecksum(int[] data, int n) {
        int checksum = 0;
        for (int i = 0; i < n; i++) {
            checksum += data[i];
            checksum = (checksum >> 16) + (checksum & 0xFFFF); // Add carry
        }
        checksum = ~checksum & 0xFFFF; // One's complement

        return checksum;
    }

    // Method to verify the checksum
    public static boolean verifyChecksum(int[] data, int n, int receivedChecksum) {
        int calculatedChecksum = calculateChecksum(data, n);
        int totalSum = (calculatedChecksum + receivedChecksum) & 0xFFFF;

        // If the sum is all 1s, the data is correct
        return totalSum == 0xFFFF;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input number of frames
        // System.out.print("Enter the number of frames (m): ");
        int m = scanner.nextInt();

        // Input number of bits per frame
        // System.out.print("Enter the number of bits per frame (n): ");
        int n = scanner.nextInt();

        // Input data frames
        int[] data = new int[m];
        for (int i = 0; i < m; i++) {
            data[i] = scanner.nextInt(2); // Input as binary
        }

        // Calculate checksum
        int checksum = calculateChecksum(data, m);
        System.out.println("Calculated Checksum (Sender Side): " + Integer.toBinaryString(checksum));

        // Simulate transmission and reception
        System.out.println("Transmitting frames and checksum...");

        // Receiver side: Verify checksum
        System.out.print("Enter the received checksum: ");
        int receivedChecksum = scanner.nextInt(2); // Input as binary

        boolean isCorrect = verifyChecksum(data, m, receivedChecksum);

        if (isCorrect) {
            System.out.println("Checksum verified. Data received correctly.");
        } else {
            System.out.println("Checksum verification failed. Data corrupted.");
        }

        scanner.close();
    }
}