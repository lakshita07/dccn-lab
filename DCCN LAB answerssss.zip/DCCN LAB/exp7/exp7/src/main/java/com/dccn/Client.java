package com.dccn;

import java.io.*;
import java.net.*;
import java.util.Scanner;

public class Client {
    public static void main(String args[]) {
        try {
            Socket socket = new Socket("localhost", 8081);
            System.out.println("Server Connected.");

            PrintWriter printWriter = new PrintWriter(socket.getOutputStream(), true);
            BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            Scanner in = new Scanner(System.in);

            System.out.print("Enter the file name to transfer from the server: ");
            String file = in.nextLine();
            printWriter.println(file);

            // Check server's response
            String response = reader.readLine();
            if (response != null && response.startsWith("Error")) {
                System.out.println("Server error: " + response);
            } else if (response != null && response.equals("File found")) {
                // Proceed with file download
                File received = new File("received_" + file);
                try (FileOutputStream fileOutputStream = new FileOutputStream(received);
                     BufferedInputStream fileReader = new BufferedInputStream(socket.getInputStream())) {

                    byte buffer[] = new byte[4096];
                    int bytesRead;
                    while ((bytesRead = fileReader.read(buffer)) != -1) {
                        fileOutputStream.write(buffer, 0, bytesRead);
                    }
                    System.out.println("File received from server successfully.");
                }
            } else {
                System.out.println("Unexpected response from server.");
            }

            // Close resources
            in.close();
            socket.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
