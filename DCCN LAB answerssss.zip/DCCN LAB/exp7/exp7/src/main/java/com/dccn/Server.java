package com.dccn;
import java.io.*;
import java.net.*;

public class Server {
    public static void main(String args[]) throws IOException{
        ServerSocket ss = new ServerSocket(8081);
        System.out.println("Server started on port 8081. Waiting for client...");

        Socket socket = ss.accept();
        System.out.println("Client Connected...");

        BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream()));

        String request = br.readLine();
        System.out.print("The requested file is: " + request + ".");

        File file = new File(request);
        // System.out.println(file);
        PrintWriter printWriter = new PrintWriter(socket.getOutputStream(), true);

        if(file.exists()) {
            BufferedInputStream reader = new BufferedInputStream(new FileInputStream(file));
            BufferedOutputStream writer = new BufferedOutputStream(socket.getOutputStream());

            byte[] buffer = new byte[4096];
            int reads;
            while((reads = reader.read(buffer)) != -1) {
                writer.write(buffer, 0, reads);
            }
            reader.close();
            writer.flush();
            writer.close();
            System.out.println("File transferred Successfully.");
        }
        else {
            printWriter.println("Error: File not found. ");
            System.out.println("File not found in directory");
        }

        printWriter.close();
        socket.close();
        ss.close();
    }
}
